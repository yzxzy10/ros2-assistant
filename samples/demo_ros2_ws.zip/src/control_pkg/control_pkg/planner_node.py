import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from vision_msgs.msg import Detection2DArray


class PlannerNode(Node):
    """按检测结果决定往哪走，输出速度指令。"""

    def __init__(self):
        super().__init__('planner_node')
        self.declare_parameter('max_speed', 0.4)
        self.declare_parameter('safe_distance', 0.8)
        self.sub = self.create_subscription(
            Detection2DArray, '/detections', self.on_detections, 10)
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)

    def on_detections(self, msg):
        cmd = Twist()
        cmd.linear.x = 0.0
        if len(msg.detections) == 0:
            cmd.linear.x = 0.4
        self.pub.publish(cmd)


def main():
    rclpy.init()
    node = PlannerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
