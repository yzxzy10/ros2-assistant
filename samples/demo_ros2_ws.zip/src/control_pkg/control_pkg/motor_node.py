import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


class MotorNode(Node):
    """把速度指令打成轮速，同时回推里程计。"""

    def __init__(self):
        super().__init__('motor_node')
        self.declare_parameter('wheel_base', 0.35)
        self.declare_parameter('wheel_radius', 0.05)
        self.sub = self.create_subscription(Twist, '/cmd_vel', self.on_cmd, 10)
        self.pub = self.create_publisher(Odometry, '/odom', 10)
        self.x = 0.0

    def on_cmd(self, msg):
        self.x += msg.linear.x * 0.05
        odom = Odometry()
        odom.pose.pose.position.x = self.x
        self.pub.publish(odom)


def main():
    rclpy.init()
    node = MotorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
