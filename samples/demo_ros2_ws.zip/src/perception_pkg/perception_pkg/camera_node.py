import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image


class CameraNode(Node):
    """模拟相机：按固定帧率往外发图像。"""

    def __init__(self):
        super().__init__('camera_node')
        self.declare_parameter('fps', 30)
        self.declare_parameter('frame_id', 'camera_link')
        self.pub = self.create_publisher(Image, '/image_raw', 10)
        self.timer = self.create_timer(1.0 / 30.0, self.tick)

    def tick(self):
        msg = Image()
        msg.height = 480
        msg.width = 640
        msg.encoding = 'rgb8'
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = CameraNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
