import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import Detection2DArray
from std_srvs.srv import Trigger


class DetectorNode(Node):
    """订阅原图，跑一遍检测，把框发出去；提供重置计数服务。"""

    def __init__(self):
        super().__init__('detector_node')
        self.declare_parameter('confidence', 0.5)
        self.sub = self.create_subscription(Image, '/image_raw', self.on_image, 10)
        self.pub = self.create_publisher(Detection2DArray, '/detections', 10)
        self.srv = self.create_service(Trigger, '/reset_detector', self.on_reset)
        self.frames = 0

    def on_image(self, msg):
        self.frames += 1
        out = Detection2DArray()
        self.pub.publish(out)

    def on_reset(self, request, response):
        self.frames = 0
        response.success = True
        response.message = 'counter reset'
        return response


def main():
    rclpy.init()
    node = DetectorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
